package demo_oracle_jdbc;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import oracle.jdbc.OracleTypes;
import oracle.jdbc.pool.OracleDataSource;

/**
 * Exemplo de classe cujas instâncias manipulam dados de BD Oracle.
 */
public class DataHandler {

    /**
     * O URL da BD.
     */
    private String jdbcUrl;

    /**
     * O nome de utilizador da BD.
     */
    private String username;

    /**
     * A password de utilizador da BD.
     */
    private String password;

    /**
     * A ligação à BD.
     */
    private Connection connection;

    /**
     * A invocação de "stored procedures".
     */
    private CallableStatement callStmt;

    /**
     * Conjunto de resultados retornados por "stored procedures".
     */
    private ResultSet rSet;

    /**
     * Constrói uma instância de "DataHandler" recebendo, por parâmetro, o URL
     * da BD e as credenciais do utilizador.
     *
     * @param jdbcUrl o URL da BD.
     * @param username o nome do utilizador.
     * @param password a password do utilizador.
     */
    public DataHandler(String jdbcUrl, String username, String password) {
        this.jdbcUrl = jdbcUrl;
        this.username = username;
        this.password = password;
        connection = null;
        callStmt = null;
        rSet = null;
    }

    /**
     * Estabelece a ligação à BD.
     */
    public void openConnection() throws SQLException {
        OracleDataSource ds = new OracleDataSource();
        ds.setURL(jdbcUrl);
        connection = ds.getConnection(username, password);
    }

    /**
     * Fecha os objetos "ResultSet", "CallableStatement" e "Connection", e
     * retorna uma mensagem de erro se alguma dessas operações não for bem
     * sucedida. Caso contrário retorna uma "string" vazia.
     */
    public String closeAll() {

        StringBuilder message = new StringBuilder("");

        if (rSet != null) {
            try {
                rSet.close();
            } catch (SQLException ex) {
                message.append(ex.getMessage());
                message.append("\n");
            }
            rSet = null;
        }

        if (callStmt != null) {
            try {
                callStmt.close();
            } catch (SQLException ex) {
                message.append(ex.getMessage());
                message.append("\n");
            }
            callStmt = null;
        }

        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException ex) {
                message.append(ex.getMessage());
                message.append("\n");
            }
            connection = null;
        }
        return message.toString();
    }

    /**
     * Exemplo de invocação de uma "stored function".
     *
     * Devolve o registo do marinheiro especificado, existente na tabela "Sailors".
     *
     * @param sailor_id o identificador do marinheiro.
     * @return o registo do marinheiro especificado ou null se esse registo não
     *         existir.
     */
    public ResultSet getSailor(int sailor_id) throws SQLException {
        /* Objeto "callStmt" para invocar a função "funcGetSailor" armazenada 
         * na BD:
         *   funcGetSailor(p_sailor_id sailors.sailor_id%TYPE) 
         *   RETURN SYS_REFCURSOR
         */
        callStmt = connection.prepareCall("{ ? = call funcGetSailor(?) }");

        // Regista o tipo de dados SQL para interpretar o resultado obtido. 
        callStmt.registerOutParameter(1, OracleTypes.CURSOR);

        // Especifica o parâmetro de entrada da função "funcGetSailor".
        callStmt.setInt(2, sailor_id);

        // Executa a invocação da função "funcGetSailor".
        callStmt.execute();

        // Guarda o cursor retornado num objeto "ResultSet".
        rSet = (ResultSet) callStmt.getObject(1);

        return rSet;
    }

    /**
     * Exemplo de invocação de uma "stored function".
     *
     * Devolve o conjunto de registos dos barcos com a cor especificada,
     * existentes na tabela "boats".
     *
     * @param color a cor dos barcos.
     * @return os registos dos barcos com a cor especificada.
     */
    public ResultSet getBoats(String color) throws SQLException {
        /* 
         * Objeto "callStmt" para invocar a função "funcBoatsColor" armazenada 
         * na BD: 
         *   funcBoatsColor(p_color boats.color%TYPE) RETURN SYS_REFCURSOR;
         */
        callStmt = connection.prepareCall("{ ? = call funcBoatsColor(?) }");

        callStmt.registerOutParameter(1, OracleTypes.CURSOR);

        callStmt.setString(2, color);

        callStmt.execute();

        rSet = (ResultSet) callStmt.getObject(1);

        return rSet;
    }

    /**
     * Exemplo de invocação de uma "stored procedure".
     *
     * Adiciona o marinheiro especificado à tabela "Sailors".
     *
     * @param sailor_id o identificador do marinheiro.
     * @param name      o nome do marinheiro.
     * @param rating    a classificação do marinheiro.
     * @param age       a idade do marinheiro.
     */
    public void addSailor(int sailor_id, String name, int rating, int age)
            throws SQLException {
        /* 
         *  Objeto "callStmt" para invocar o procedimento "procAddSailor" 
         *  armazenado na BD:
         *    PROCEDURE procAddSailor( p_sailor_id  sailors.sailor_id%TYPE, 
         *                             p_name       sailors.name%TYPE, 
         *                             p_rating     sailors.rating%TYPE, 
         *                             p_age        sailors.age%TYPE)
         */
        callStmt = connection.prepareCall("{ call procAddSailor(?,?,?,?) }");

        callStmt.setInt(1, sailor_id);
        callStmt.setString(2, name);
        callStmt.setInt(3, rating);
        callStmt.setInt(4, age);

        callStmt.execute();

    }

    /**
     * Exemplo de invocação de uma "stored procedure".
     *
     * Remove o marinheiro especificado da tabela "Sailors".
     *
     * @param sid o identificador do marinheiro a remover.
     */
    public void removeSailor(int sid) throws SQLException {
        /* 
         *  Objeto "callStmt" para invocar o procedimento "procRemoveSailor" 
         *  armazenado na BD:
         *     PROCEDURE procRemoveSailor(p_sailor_id sailors.sailor_id%TYPE)
         */
        callStmt = connection.prepareCall("{ call procRemoveSailor(?) }");

        callStmt.setInt(1, sid);

        callStmt.execute();

    }
    
    /**
     * Exemplo de invocação de uma "stored procedure" que gera uma exceção.
     */
    public void raiseException() throws SQLException {
        /* 
         *  Objeto "callStmt" para invocar o procedimento "procRaiseException" 
         *  armazenado na BD:
         *     PROCEDURE procRaiseException
         */
        callStmt = connection.prepareCall("{ call procRaiseException }");

        callStmt.execute();

    }    

}
