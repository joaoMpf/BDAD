--delete existing tables (if any)

DROP TABLE sailors  CASCADE CONSTRAINTS PURGE;
DROP TABLE boats    CASCADE CONSTRAINTS PURGE;
DROP TABLE reserves CASCADE CONSTRAINTS PURGE;

--create tables

CREATE TABLE sailors(
  sailor_id INTEGER 	CONSTRAINT pk_sailors_sailor_id PRIMARY KEY,
  name 	    VARCHAR(30)	CONSTRAINT nn_sailors_name      NOT NULL,
  rating    INTEGER		CONSTRAINT nn_sailors_rating    NOT NULL,
  age 		INTEGER	    CONSTRAINT nn_sailors_age       NOT NULL
);

CREATE TABLE boats(
  boat_id 	INTEGER     CONSTRAINT pk_boats_boat_id PRIMARY KEY,
  name      VARCHAR(20) CONSTRAINT nn_boats_name    NOT NULL,
  color     VARCHAR(10) CONSTRAINT nn_boats_color   NOT NULL
);

CREATE TABLE reserves(
  sailor_id INTEGER,
  boat_id 	INTEGER,
  day 	    DATE     CONSTRAINT nn_reserves_day NOT NULL, 
  CONSTRAINT pk_reserves_sailor_id_boat_id PRIMARY KEY(sailor_id, boat_id, day)
);

ALTER TABLE reserves ADD CONSTRAINT fk_reserves_sailor_id FOREIGN KEY (sailor_id) REFERENCES sailors(sailor_id);
ALTER TABLE reserves ADD CONSTRAINT fk_reserves_boat_id   FOREIGN KEY (boat_id)   REFERENCES boats(boat_id);

--populate table
  
INSERT INTO sailors VALUES(22, 'Dustin',  7, 45);
INSERT INTO sailors VALUES(29, 'Brutus',  1, 33);
INSERT INTO sailors VALUES(31, 'Lubber',  8, 55);
INSERT INTO sailors VALUES(32, 'Andy',    8, 25);
INSERT INTO sailors VALUES(58, 'Rusty',  10, 35);
INSERT INTO sailors VALUES(64, 'Horacio', 7, 35);
INSERT INTO sailors VALUES(71, 'Zorba',  10, 16);
INSERT INTO sailors VALUES(74, 'Horacio', 9, 35);
INSERT INTO sailors VALUES(85, 'Art',     3, 25);
INSERT INTO sailors VALUES(95, 'Bob',     3, 63);
INSERT INTO sailors VALUES(13, 'Popeye',  3, 22);
INSERT INTO sailors VALUES(44, 'Haddock', 3, 63);

INSERT INTO boats VALUES(101, 'Interlake', 'blue');
INSERT INTO boats VALUES(102, 'Interlake', 'red');
INSERT INTO boats VALUES(103, 'Clipper',   'green');
INSERT INTO boats VALUES(104, 'Marine',    'red');
  
INSERT INTO reserves VALUES(22, 101, TO_DATE('2017/10/10','yyyy/mm/dd'));
INSERT INTO reserves VALUES(22, 102, TO_DATE('2017/10/10','yyyy/mm/dd'));
INSERT INTO reserves VALUES(22, 103, TO_DATE('2017/08/10','yyyy/mm/dd'));
INSERT INTO reserves VALUES(22, 104, TO_DATE('2017/07/10','yyyy/mm/dd'));
INSERT INTO reserves VALUES(31, 102, TO_DATE('2017/10/11','yyyy/mm/dd'));
INSERT INTO reserves VALUES(31, 103, TO_DATE('2017/06/11','yyyy/mm/dd'));
INSERT INTO reserves VALUES(31, 104, TO_DATE('2017/12/11','yyyy/mm/dd'));
INSERT INTO reserves VALUES(64, 101, TO_DATE('2017/05/09','yyyy/mm/dd'));
INSERT INTO reserves VALUES(64, 102, TO_DATE('2017/08/09','yyyy/mm/dd'));
INSERT INTO reserves VALUES(64, 102, TO_DATE('2017/09/09','yyyy/mm/dd'));
INSERT INTO reserves VALUES(64, 102, TO_DATE('2017/10/09','yyyy/mm/dd'));
INSERT INTO reserves VALUES(74, 103, TO_DATE('2017/08/09','yyyy/mm/dd'));
INSERT INTO reserves VALUES(44, 101, TO_DATE('2018/05/09','yyyy/mm/dd'));
INSERT INTO reserves VALUES(44, 101, TO_DATE('2018/09/09','yyyy/mm/dd'));