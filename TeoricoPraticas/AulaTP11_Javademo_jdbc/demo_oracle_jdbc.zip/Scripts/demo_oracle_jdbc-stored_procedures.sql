-- Fun��o retorna a refer�ncia de um objeto cursor
CREATE OR REPLACE FUNCTION funcGetSailor(p_sailor_id sailors.sailor_id%TYPE)
RETURN SYS_REFCURSOR
AS
  l_refcur_sailor SYS_REFCURSOR;	-- vari�vel de cursor do tipo predefinido SYS_REFCURSOR 
BEGIN
  -- criar um objeto cursor e armazenar a refer�ncia desse objeto na vari�vel de cursor l_refcur_sailor
  OPEN l_refcur_sailor FOR 
    SELECT * FROM sailors WHERE sailor_id = p_sailor_id; 

  -- retornar a refer�ncia do objeto cursor armazenado na vari�vel de cursor l_refcur_sailor
  RETURN l_refcur_sailor;
END;
/

CREATE OR REPLACE FUNCTION funcBoatsColor(p_color boats.color%TYPE)
RETURN SYS_REFCURSOR
AS
  l_refcur_boats SYS_REFCURSOR;
BEGIN
  OPEN l_refcur_boats FOR 
    SELECT * FROM boats WHERE boats.color = p_color;
  RETURN l_refcur_boats;        
END;
/

CREATE OR REPLACE PROCEDURE procAddSailor(
    p_sailor_id sailors.sailor_id%TYPE, 
    p_name      sailors.name%TYPE, 
    p_rating    sailors.rating%TYPE, 
    p_age       sailors.age%TYPE) 
AS
BEGIN
  INSERT INTO sailors(sailor_id, name, rating, age) VALUES(p_sailor_id, p_name, p_rating, p_age);   
END;
/

CREATE OR REPLACE PROCEDURE procRemoveSailor(p_sailor_id sailors.sailor_id%TYPE) 
IS
BEGIN
  DELETE FROM sailors WHERE sailor_id = p_sailor_id;   
END;
/

CREATE OR REPLACE PROCEDURE procRaiseException 
IS
    l_boat_id boats.boat_id%TYPE;
BEGIN
  SELECT boat_id INTO l_boat_id FROM boats WHERE boat_id=-100;
END;
/